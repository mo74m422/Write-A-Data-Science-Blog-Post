
### Write-A-Data-Science-Blog-Post
 
 A Udacity Data Scientist Nanodegree Project
    
    
## Project Motivation

In this project, Stack Overflow Developer Survey, 2017 is chosen as the dataset to be analyzed and understand the following questions:

# Questions:

Q1 which are the top 5 countries conducting the survey?
 Q2 How many types of answers included in 'Professional' column ?
 Q3 Comparison Professional with each top five countries
 Q4 Comparison top five countries togther with Professional

 Q5 How many types of answers included in 'FormalEducation' column

 Q6 How many types of answers included in 'EmploymentStatus' column
 Q7 how many years program vs Salary
